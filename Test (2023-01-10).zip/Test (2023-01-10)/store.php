<?php
include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <?php
        if(isset($_POST['submit']))
        {
            $count = $_POST['count'];
            $i=0;
            for($i=0;$i<$count;$i++)
            {
                $user =  "usr".$i;
                $dob =  "dob".$i;
                $age =  "age".$i;
                $username = $_POST[$user];
                $dob = $_POST[$dob]; 
                $age = $_POST[$age]; 
                $sql = "insert into user(name,dob,age) values('$username','$dob','$age')";
                $res = mysqli_query($conn,$sql); 
            }
            

            // $last_insert_id = mysqli_insert_id($conn);

            header('location: ./view.php');
        }

    ?>
</body>
</html>