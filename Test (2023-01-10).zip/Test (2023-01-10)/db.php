<?php

    $host = "localhost";
    $username = "root";
    $psw = "";
    $db = "user_db";

    $conn = mysqli_connect($host,$username,$psw,$db);

    if(!$conn)
    {
        die("dfdsfs");
    }

?>