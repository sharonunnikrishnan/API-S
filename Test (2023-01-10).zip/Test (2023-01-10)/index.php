<?php
include "db.php";
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container" style="margin-top:80px;">
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <h1>User Registration</h1>
                    <?php
                        $user = "";
                        $dob = "";
                        $age = "";
                        if(isset($_GET['id']))
                        {
                            
                            
                            $id=$_GET['id'];
                            $qry = "select * from user where id=$id";
                            $result = mysqli_query($conn,$qry); 

                            foreach($result as $res)
                            {
                                $user = $res['name'];
                                $dob = $res['dob'];
                                $age = $res['age'];
 
                            }
                        }
                    ?>
                    <label>Name</label>
                    <input type="text" name="username" id="username" class="form-control" value="<?= $user ?>"><br><br>
                    <label>D.O.B</label>
                    <input type="date" id="dob" name="dob" onchange="getAge()" class="form-control" value="<?= $dob ?>"><br><br>
                    <label>Age</label>
                    <input type="text" name="age" id="age" class="form-control" value="<?= $age ?>"><br><br>

                    <input type="button" value="Add" onclick="addDetails()" class="btn btn-info">
                    
                
            </div>
            <div class="col-sm-2"></div>
        </div>
    </div>
    <div class="container" style="margin-top:80px;">
        <div class="row">
            <div class="col-sm-2"></div>
            <div class="col-sm-8">
                <div class="view_table" id="formdata" style="display:none">

                    
                </div>

                
            </div>
            <div class="col-sm-2"></div>
            
        </div>
    </div>
</body>
</html>

<script>
    var usernames = [];
    var dobs = [];
    var ages = [];
    
    function getAge()
    {
        date = document.getElementById("dob").value;
        // alert(date);
        var today = new Date();
        var birthDate = new Date(date);
        var age = today.getFullYear() - birthDate.getFullYear();
        var m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        
        document.getElementById("age").value= age;
    }

    function addDetails()
    {
        document.getElementById("formdata").style.display='block';
        document.getElementById("formdata").innerHTML='';
        var data ='';

        username = document.getElementById('username').value;
        usernames.push(username);   
        dob = document.getElementById("dob").value;
        dobs.push(dob);
        age = document.getElementById("age").value;
        ages.push(age); 
 
        var arrayLength = usernames.length;
        
        data += '<form method="post" action="store.php"> <table border="1" class="table" > <tr> <th>Name</th> <th>DOB</th> <th>Age</th> </tr>';
        for (var i = 0; i < arrayLength; i++) { 
            data += '<tr><td><input type="text" id='+ usernames[i] +' name="usr' + i +'" value='+ usernames[i] +'></td> <td><input type="text" id="dob1" name="dob'+ i +'" value='+ dobs[i] +'></td><td><input type="text" id="age1" name="age'+ i +'"  value='+ ages[i] +'></td></tr>' 
 
        }
        data += '<input type="text" name="count" value='+ i +'>';
        data += '</table>';
        data += '<input type="submit" value="Save" name="submit" class="btn btn-info">'
        data += '</form>'
        document.getElementById("formdata").innerHTML=data;

        // document.getElementById("username1").value=username; 
        // document.getElementById("dob1").value=dob; 
        // document.getElementById("age1").value=age; 
        
    }

    
</script>